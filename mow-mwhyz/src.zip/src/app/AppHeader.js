
import './AppHeader.css';
import loco from '../img/logo.png';
import useSticky from './useSticky';
import classNames from 'classnames';



export default function AppHeader(){

const {sticky, stickyRef, link} = useSticky();

    return (
        <>
            <div className="header" id='header'>
                <a href="/"><h1>Meals On Wheels</h1></a>
                <img src={loco}  alt="" className="logo"/>
            </div>

            <nav ref={stickyRef} className={classNames('nav', { sticky })}>
                <div className="nav-left">
                    <ul>
                        <li><a href="/shop" className={classNames('a', { link })} >Shops</a></li>
                        <li><a href="/contact" className={classNames('a', { link })}>Contact Us</a></li>
                        <li><a href="/about" className={classNames('a', { link })}>About Us</a></li>
                    </ul>
                </div>
                <div className="nav-middle" >
                    <img src={loco}  alt="" id='nav-middle-img' />
                </div>
                <div className="nav-right">
                    <ul>
                        <li><a href="/register" className={classNames('a', { link })}>Register</a></li>
                        <li><a href="/login" className={classNames('a', { link })}>Login</a></li>
                        <li><a href="/donate" id="donate" className={classNames('a', { link })}>Donate</a></li>
                    </ul>
                </div>
            </nav>
        </>
    )

}
