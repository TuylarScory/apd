import React, { Component } from 'react'
import AppHeader from '../app/AppHeader'
import './AppHeader.css'
import {Route, Switch} from 'react-router-dom';
import AppFooter from '../app/AppFooter';
import 'react-s-alert/dist/s-alert-default.css';
import 'react-s-alert/dist/s-alert-css-effects/slide.css';
import Login from '../component/login/Login'
import Landing from '../home/landing'
import Register from '../component/signup/Register';
import About from '../component/aboutus/About';
import Contact from '../component/contact/Contact';

export const ACCESS_TOKEN = 'accessToken';

export class App extends Component {
  render() {
    return (

        <>
          <AppHeader/>
        

          
          
          <Switch>
            <Route exact path="/" component={Landing}></Route>
            <Route path="/login" component={Login}></Route>  
            <Route path="/register" component={Register}></Route>  
            <Route path="/about" component={About}></Route>  
            <Route path="/contact" component={Contact}></Route>  
         
          </Switch>


          <AppFooter/>
          </>
    )
  }
}

export default App