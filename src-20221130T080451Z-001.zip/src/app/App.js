import React, { Component } from 'react'
import AppHeader from '../app/AppHeader'
import './AppHeader.css'
import {Route, Switch} from 'react-router-dom';
import { getCurrentUser } from '../service/FoodService';
import AppFooter from '../app/AppFooter';
import PrivateRoute from './PrivateRoute';
import 'react-s-alert/dist/s-alert-default.css';
import 'react-s-alert/dist/s-alert-css-effects/slide.css';
import Login from '../component/login/Login'
import Landing from '../home/landing'
import Register from '../component/signup/Register';
import AdminHomePage from '../component/admin/AdminHomePage'
import SingleMember from '../component/admin/SingleMember'
import SinglePartner from '../component/admin/SinglePartner'
import SingleVolunteer from '../component/admin/SingleVolunteer'
import AddAdmin from '../component/admin/AddAdmin'
import VolunteerProfile from '../component/profile/VolunteerProfile'
import About from '../component/aboutus/About';
import Contact from '../component/contact/Contact';

export const ACCESS_TOKEN = 'accessToken';

export class App extends Component {

  constructor(props) {
    super(props);
    this.state = {
      authenticated: false,
      currentUser: null,
      loading: false
    }

    this.loadCurrentlyLoggedInUser = this.loadCurrentlyLoggedInUser.bind(this);
  }

  loadCurrentlyLoggedInUser() {
    this.setState({
      loading: true
    });

    getCurrentUser()
    .then(response => {
      this.setState({
        currentUser: response,
        authenticated: true,
        loading: false
      });
    }).catch(error => {
      this.setState({
        loading: false
      });  
    });    
  }

  componentDidMount() {
    this.loadCurrentlyLoggedInUser();
  }

  render() {
    return (

        <>
          <AppHeader authenticated={this.state.authenticated}/>
        

          
          
          <Switch>
            <Route exact path="/" component={Landing}></Route>
            <Route path="/login"
              render={(props) => <Login authenticated={this.state.authenticated} currentUser={this.state.currentUser} {...props} />}></Route> 

             <Route path="/register" render={(props) => <Register authenticated={this.state.authenticated} {...props} />}></Route>

             <PrivateRoute path="/admin" authenticated={this.state.authenticated} currentUser={this.state.currentUser}
              component={AdminHomePage}></PrivateRoute>

              <Route path="/get/:id" authenticated={this.state.authenticated} currentUser={this.             state.currentUser} 
              component={SingleMember}></Route>
              
              <PrivateRoute path="/getPartner/:id" authenticated={this.state.authenticated} currentUser={this.state.currentUser} 
              component={SinglePartner}></PrivateRoute>

              <PrivateRoute path="/getVolunteer/:id" authenticated={this.state.authenticated} currentUser={this.state.currentUser} 
              component={SingleVolunteer}></PrivateRoute>

              <PrivateRoute path="/addAdmin" authenticated={this.state.authenticated} currentUser={this.state.currentUser} 
              component={AddAdmin}></PrivateRoute>

              <PrivateRoute path="/profile" authenticated={this.state.authenticated} currentUser={this.state.currentUser} 
              component={VolunteerProfile}></PrivateRoute>

            <Route path="/about" component={About}></Route>  
            <Route path="/contact" component={Contact}></Route>  
         
          </Switch>


          <AppFooter/>
          </>
    )
  }
}

export default App