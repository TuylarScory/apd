import { useEffect, useRef, useState } from 'react';
import './AppHeader.css';

const useSticky = () => {
  const stickyRef = useRef(null);
  const [sticky, setSticky] = useState(false);
  const [offset, setOffset] = useState(0);
  const [link, setColorchange] = useState(false);
 

  useEffect(() => {
    if (!stickyRef.current) {
      return;
    }
    setOffset(stickyRef.current.offsetTop);
  }, [stickyRef, setOffset]);

  useEffect(() => {
    const handleScroll = () => {
      if (!stickyRef.current) {
        return;
      }
      setSticky(window.scrollY > offset);
    };
    

    const changeNavbarColor = () => {
        if(window.scrollY > offset){
            setColorchange(true);
        }
        else{
            setColorchange(false);
        }
    };

    const showImage = () => {
      // document.getElementById("nav-middle-img").style.display = "none"
      if(window.scrollY > offset) {
        document.getElementById("nav-middle-img").style.display = "block"
        document.getElementById("nav-middle-img").style.padding = "10px 0"
      } else {
        document.getElementById("nav-middle-img").style.display = "none"
      }
    }


    
    window.addEventListener('scroll', handleScroll);
    window.addEventListener('scroll', changeNavbarColor);
    window.addEventListener('scroll', showImage);
    

    return () => { 
        window.removeEventListener('scroll', handleScroll);
        window.removeEventListener('scroll', changeNavbarColor);
        window.addEventListener('scroll', showImage);
    };
    
  }, [setSticky, stickyRef, offset, setColorchange]);
  return { stickyRef, sticky, link};
};



export default useSticky;